<?php  
   $user = 'cfavouri_iotdata'; 
   $password = 'iotdataiotdata'; 
   $database = 'cfavouri_iotdata'; 
   $db = new mysqli('localhost',$user,$password,$database); 
 ?>