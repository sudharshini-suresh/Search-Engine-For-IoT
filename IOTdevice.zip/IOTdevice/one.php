<?php 

$url = "https://iotdatadcu.com/IOTdevice/iot.php?pass=arun";

//call api
$json = file_get_contents($url);


$jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';

$arr = json_decode($json, true);

echo $arr["a"];
echo $arr["b"];
echo $arr["c"];


?>