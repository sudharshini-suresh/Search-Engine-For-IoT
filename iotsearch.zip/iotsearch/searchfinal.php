<?php
 
$button = $_GET ['submit'];
$search = $_GET ['search']; 
 
if(!$button)
echo "you didn't submit a keyword";
else
{
    
    	$db_host = 'localhost';
		$db_user = 'cfavouri_mirror';
		$db_pass = 'mirror948474';
		$db_name = 'cfavouri_mirrordb';
		//$con = mysql_connect($db_host, $db_user, $db_pass);
		$con = mysqli_connect($db_host, $db_user, $db_pass,$db_name);

		$details = array();
	//	echo $_REQUEST['pass'];
		$sql = "SELECT distinct * FROM temp_iot where  d LIKE '%$search%'";
		
	//	SELECT distinct * FROM temp_iot WHERE d LIKE '%$keyword%'"
	//	echo $sql;
		$res = mysqli_query($con,$sql);
		while($row = mysqli_fetch_assoc($res) )
		{
         	$temp=$row['a'];
         	
         	echo "Current Temperature is: ".$temp;
			
			
		}
		
	//	echo $details;

	}

 
?>