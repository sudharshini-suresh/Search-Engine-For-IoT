<html>
<head>
<title>Title of your search engine - pakainfo.com</title>
</head>
<body>
<form action='searchfinal.php' method='GET'>
<center>
<h1>Pakainfo - Search Engine</h1>
<input type='text' size='90' name='search'></br></br>
<input type='submit' name='submit' value='You have simple Search source code' ></br></br></br>
</center>
</form>
</body>
</html>
