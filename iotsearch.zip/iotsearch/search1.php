<html>
<head>
<title>Title of your search engine - pakainfo.com</title>
</head>
<body>
<form action='search.php' method='GET'>
<center>
<h1>Pakainfo - Search Engine</h1>
<input type='text' size='90' name='search'></br></br>
<input type='submit' name='submit'></br></br></br>
</center>
</form>
</body>
</html>
