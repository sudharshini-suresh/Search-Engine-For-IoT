<?php
include("config.php");
if(isset($_GET['q']) && $_GET['q']!="") :
    $data = mysqli_real_escape_string($db,$_GET['q']);
    $keyword =  trim(preg_replace('/\s+/',' ',$data));
    $sql=$db->query("SELECT distinct * FROM web_information WHERE meta_title LIKE '%$keyword%' OR meta_description LIKE '%$keyword%' OR site_url LIKE '%$keyword%'");
?>
    <html>
    <head>        
        <link rel="stylesheet" href="st.css" />
    </head>
    <body>
    <div>
        <form action="search_result.php" id="search_form" method="GET">
            <input name="q" autocomplete="off" id="list_search" type="search" required value="<?=@$keyword;?>" class="search" />
            <button type="submit"  class="but_blue">Search</button>      
        </form>
    </div>
    <div>
    <?php if(isset($sql) && count($sql) && ($sql->num_rows)) : ?>
    <div class="reslt_bar">                
        <?php foreach ($sql as $key => $search_data) : ?>
            <p><a target="_blank" href='<?=$search_data['site_url'] ?>'><?=$search_data['meta_title'] ?></a><br/>
            <?=$dbContent = str_ireplace($keyword,'<b>'.$keyword.'</b>',$search_data['site_url']); ?></br>                       
            <?=$dbContent = str_ireplace($keyword,'<b>'.$keyword.'</b>',$search_data['meta_description']); ?></p>
        <?php endforeach; ?>                
    </div>
    <?php else :?>
    <p>Your search - <b><?=@$keyword;?></b> - did not match any documents.</p>        
    <?php endif; ?>
    </div>
 <?php endif; ?>


 <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript">
$(document).ready(function(){
    $(document).on('keyup','#list_search',function(){   
        var value = $(this).val();
        $.getJSON('ajax_search_list.php?q='+value, function (data) {
            var availableTags = data;
            $( "#list_search" ).autocomplete({
                source: availableTags,
                select: function(event, ui) {
                $(event.target).val(ui.item.value);
                $('#search_form').submit();
                return false;
            },
             });
        });
        
    });
});
</script>
            
            
   

