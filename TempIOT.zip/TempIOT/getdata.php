<?php
// function definitions
function get_input_params() 
{
	$input_params = array();
	$input_params['a'] = isset($_REQUEST['a'])?$_REQUEST['a']:NULL;
	$input_params['pass'] = isset($_REQUEST['pass'])?$_REQUEST['pass']:NULL;
	$input_params['a'] = trim($input_params['a']);
	$input_params['pass'] = trim($input_params['pass']);
	return $input_params;
}

function authenticate($input_params) 
{
	if ( $input_params['pass'] == 'arun' )
		return true;
	else
		return false;
}

function db_connect() 
{
	$db_host = 'localhost';
	$db_user = 'cfavouri_mirror';
	$db_pass = 'mirror948474';
	$db_name = 'cfavouri_mirrordb';
	//$con = mysql_connect($db_host, $db_user, $db_pass);
	$con = mysqli_connect($db_host, $db_user, $db_pass,$db_name);
	//$res = mysql_select_db($db_name);
	//if ( !$res )
	//{
	//	send_response('', false);
	//}
}

function db_close()
{
	mysqli_close();
}

function insert_or_update($input_params) 
{
	$status = false;
	
	$db_host = 'localhost';
		$db_user = 'cfavouri_mirror';
		$db_pass = 'mirror948474';
		$db_name = 'cfavouri_mirrordb';
		//$con = mysql_connect($db_host, $db_user, $db_pass);
		$con = mysqli_connect($db_host, $db_user, $db_pass,$db_name);



//$rowSQL = mysql_query( "SELECT MAX( id ) AS max FROM energyview_data;" );
//$row = mysql_fetch_array( $rowSQL );
//$id = $row['max'];

//$id = $id + 1;
	//$id = 1;
	$sql = "INSERT INTO temp_data (a) VALUES ('{$input_params["a"]}') ";
	$res = mysqli_query($con,$sql);
	return $res;
}

function get_details() 
{
    
    $db_host = 'localhost';
		$db_user = 'cfavouri_mirror';
		$db_pass = 'mirror948474';
		$db_name = 'cfavouri_mirrordb';
		//$con = mysql_connect($db_host, $db_user, $db_pass);
		$con = mysqli_connect($db_host, $db_user, $db_pass,$db_name);


//	$details = array();
	$details = '';
	$sql = 'SELECT * FROM temp_data';
	$res = mysqli_query($con,$sql);
	while( $row = mysqli_fetch_assoc($res) )
	{
//		$details['a'] = $row['a'];
		$details = $row['a'];
		//echo $details;

	}

	$sql = 'DELETE FROM temp_data';
	$res = mysqli_query($con,$sql);
	//echo $res;

	return $details;
}

function send_response($msg = '', $status = false) 
{
	if ($status)
	{
		if ($msg == '')
			echo $msg;
		else	
			echo $msg;
	}
	else
	{
		if ($msg == '')
			echo "Some error happened. Please try again later";
		else	
			echo $msg;
	}
}

$input_params = array();
$authenticated = false;

$input_params = get_input_params();

if ( isset($input_params['pass']) && $input_params['pass'] != NULL && $input_params['pass'] != '' )
	$authenticated = authenticate($input_params);

if ( !$authenticated) 
{
	send_response('Invalid credentials', false);
	exit;
}	

db_connect();
if( isset($input_params['a']) && $input_params['a'] != '' && $input_params['a'] != NULL )
{
	$status = false;
	$status = insert_or_update($input_params);
	if ($status) 
	{
		send_response('', true);
	} 
	else
	{
		send_response('', false);
	}
} 
else {
	$details = get_details();
send_response($details,true);

//	if ( is_array($details) && count($details) > 0 ) 
//	{
//		$json_details = json_encode($details);
//		send_response($json_details, true);
//	} 
//	else
//	{
//		send_response('No Records Found', false);
//	}

}
//db_close();
?>