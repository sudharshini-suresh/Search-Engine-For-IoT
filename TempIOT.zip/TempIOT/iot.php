	<?php
	// function definitions
	function get_input_params() 
	{
		$input_params = array();
		$input_params['a'] = isset($_REQUEST['a'])?$_REQUEST['a']:NULL;
		$input_params['b'] = isset($_REQUEST['b'])?$_REQUEST['b']:NULL;
		$input_params['c'] = isset($_REQUEST['c'])?$_REQUEST['c']:NULL;
		$input_params['d'] = isset($_REQUEST['d'])?$_REQUEST['d']:NULL;
		$input_params['e'] = isset($_REQUEST['e'])?$_REQUEST['e']:NULL;
		$input_params['pass'] = isset($_REQUEST['pass'])?$_REQUEST['pass']:NULL;
		$input_params['a'] = trim($input_params['a']);
		$input_params['b'] = trim($input_params['b']);
		$input_params['c'] = trim($input_params['c']);
		$input_params['d'] = trim($input_params['d']);
		$input_params['e'] = trim($input_params['e']);
		$input_params['pass'] = trim($input_params['pass']);
		return $input_params;
	}

	function authenticate($input_params) 
	{
		if ( $input_params['pass'] == 'arun' )
			return true;
		else
			return false;
	}

	function db_connect() 
	{
		$db_host = 'localhost';
		$db_user = 'cfavouri_mirror';
		$db_pass = 'mirror948474';
		$db_name = 'cfavouri_mirrordb';
		//$con = mysql_connect($db_host, $db_user, $db_pass);
		$con = mysqli_connect($db_host, $db_user, $db_pass,$db_name);
		//$res = mysql_select_db($db_name);
		//if ( !$res )
		//{
		//	send_response('', false);
		//}
	}

	function db_close()
	{
		mysqli_close();
	}

	function insert_or_update($input_params) 
	{
		$status = false;
		
		$db_host = 'localhost';
		$db_user = 'cfavouri_mirror';
		$db_pass = 'mirror948474';
		$db_name = 'cfavouri_mirrordb';
		//$con = mysql_connect($db_host, $db_user, $db_pass);
		$con = mysqli_connect($db_host, $db_user, $db_pass,$db_name);


	//$rowSQL = mysql_query( "SELECT MAX( id ) AS max FROM energyview_data;" );
	//$row = mysql_fetch_array( $rowSQL );
	//$id = $row['max'];

	//$id = $id + 1;
		//$id = 1;

	if($input_params["a"] != '2000'){
		$sql = "update temp_iot set a = '{$input_params["a"]}'";
		$res = mysqli_query($con,$sql);
//		return $res;
	}
	
	if($input_params["b"] != '2000'){
		$sql = "update temp_iot set b = '{$input_params["b"]}'";
		$res = mysqli_query($con,$sql);
//		return $res;
	}

	if($input_params["c"] != '2000'){
		$sql = "update temp_iot set c = '{$input_params["c"]}'";
		$res = mysqli_query($con,$sql);
//		return $res;
	}

	if($input_params["d"] != '2000'){
		$sql = "update temp_iot set d = '{$input_params["d"]}'";
		$res = mysqli_query($con,$sql);
//		return $res;
	}

	if($input_params["e"] != '2000'){
		$sql = "update temp_iot set e = '{$input_params["e"]}'";
		$res = mysqli_query($con,$sql);
		return $res;
	}	
//		$sql = "INSERT INTO temp_iot (a, b, c,d,e) VALUES ( '{$input_params["a"]}', '{$input_params["b"]}', '{$input_params["c"]}', '{$input_params["d"]}', //'{$input_params["e"]}') ";
		
//		$res = mysql_query($sql);
//		return $res;
	}

	function get_details() {
	
	$db_host = 'localhost';
		$db_user = 'cfavouri_mirror';
		$db_pass = 'mirror948474';
		$db_name = 'cfavouri_mirrordb';
		//$con = mysql_connect($db_host, $db_user, $db_pass);
		$con = mysqli_connect($db_host, $db_user, $db_pass,$db_name);

		$details = array();
		$sql = 'SELECT * FROM temp_iot';
		$res = mysqli_query($con,$sql);
		while( $row = mysqli_fetch_assoc($res) )
		{
			$details['a'] = $row['a'];
			$details['b'] = $row['b'];
			$details['c'] = $row['c'];
			$details['d'] = $row['d'];
			$details['e'] = $row['e'];
		}
		return $details;
	}

	function send_response($msg = '', $status = false) 
	{
		if ($status)
		{
			if ($msg == '')
				echo "Success";
			else	
				echo $msg;
		}
		else
		{
			if ($msg == '')
				echo "Some error happened. Please try again later";
			else	
				echo $msg;
		}
	}

	$input_params = array();
	$authenticated = false;

	$input_params = get_input_params();

	if ( isset($input_params['pass']) && $input_params['pass'] != NULL && $input_params['pass'] != '' )
		$authenticated = authenticate($input_params);

	if ( !$authenticated) 
	{
		send_response('Invalid credentials', false);
		exit;
	}	

	db_connect();
	if( isset($input_params['a']) && $input_params['a'] != '' && $input_params['a'] != NULL && isset($input_params['b']) && $input_params['b'] != '' && $input_params['b'] != NULL && isset($input_params['c']) && $input_params['c'] != '' && $input_params['c'] != NULL )
	{
		$status = false;
		$status = insert_or_update($input_params);
		if ($status) 
		{
			send_response('', true);
		} 
		else
		{
			send_response('', false);
		}
	} 
	else {
		$details = get_details();
		if ( is_array($details) && count($details) > 0 ) 
		{
			$json_details = json_encode($details);
			send_response($json_details, true);
		} 
		else
		{
			send_response('No Records Found', false);
		}
	}
	db_close();
	?>