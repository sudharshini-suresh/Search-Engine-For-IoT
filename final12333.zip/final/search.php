<?php
	if(isset($_POST['search'])){
		$keyword = $_POST['keyword'];
	//	echo $keyword;
	 
?>
<div>
	<h2>View Result</h2>
	<hr style="border-top:2px dotted #ccc;"/>
	<?php
	
    	$db_host = 'localhost';
		$db_user = 'cfavouri_mirror';
		$db_pass = 'mirror948474';
		$db_name = 'cfavouri_mirrordb';
		//$con = mysql_connect($db_host, $db_user, $db_pass);
		$con = mysqli_connect($db_host, $db_user, $db_pass,$db_name);

		$details = array();
	//	echo $_REQUEST['pass'];
	
	        $word='dcu main building';
	        $keyword1=strtolower($keyword);
	      //  echo $keyword1;
	     //  echo str_contains($keyword, 'temperature');
	     if(strpos(($keyword1), $word) !== false){
	
		$sql = "SELECT distinct * FROM temp_iot where  lower(d) LIKE '%$word%' COLLATE utf8_general_ci";
		
	//	SELECT distinct * FROM temp_iot WHERE d LIKE '%$keyword%'"
	    //echo $sql;
		$res = mysqli_query($con,$sql);
		
		if($res)
		{
		
		while($row = mysqli_fetch_assoc($res) )
		{
		    $temperature='temperature';
		    
		    
		   if(strpos($keyword1, $temperature) !== false)
		   {
		       
		   
    ?>
	<div style="word-wrap:break-word;">
		<h4>Temperature :<?php echo $row['a']?></h4>

	</div>
	<hr style="border-bottom:1px solid #ccc;"/>
	
	
	<?php
		   }
		   
		   
		   
		   
		    $humidity='humidity';
		    
		    
		   if(strpos($keyword1, $humidity) !== false)
		   {
		       
		   
    ?>
	<div style="word-wrap:break-word;">
		<h4>Humidity :<?php echo $row['b']?></h4>

	</div>
	<hr style="border-bottom:1px solid #ccc;"/>
	
	
	<?php
		   }
		   
		   
		   
		   
		   
		    $gas='gas';
		    
		    
		   if(strpos($keyword1, $gas) !== false)
		   {
		       
		   
    ?>
	<div style="word-wrap:break-word;">
		<h4>Gas Power: <?php echo $row['c']?></h4>

	</div>
	<hr style="border-bottom:1px solid #ccc;"/>
	
	
	<?php
		   }
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		}
		
		}
		
			else 
	   {
	       echo "No Record Found";
	       
	   }
	
	   
	   
	   
	?>
</div>
<?php
	}
	
	   
	$iot1='dublin';
	
	 if(strpos($keyword1,$iot1)!==false)
	   {
	
	$sql = "SELECT distinct * FROM temp_iot1 where  lower(location) LIKE '%$iot1%'";
		
	//	SELECT distinct * FROM temp_iot1 WHERE location LIKE '%$keyword%'"
		//echo $sql;
		$res = mysqli_query($con,$sql);
	
	  if($res)
	  {
		while($row = mysqli_fetch_assoc($res) )
		{
		    
		    $temperature='temperature';
		    if(strpos($keyword1,$temperature)!==false)
		    {
    ?>
	<div style="word-wrap:break-word;">
		<h4>Temperature :<?php echo $row['temperature']?></h4>

	</div>
	<hr style="border-bottom:1px solid #ccc;"/>
	<?php
		    }
		}
	   
	  }
	  	else 
	   {
	       echo "No Record Found";
	       
	   }
	
	   
	?>
</div>
<?php
	}
	
	 $iot2='galway';
	
	 if(strpos($keyword1,$iot2)!==false)
	   {
	
		$sql = "SELECT distinct * FROM temp_iot2 where  lower(location) LIKE '%$iot2%' COLLATE utf8_general_ci";
		
	//	SELECT distinct * FROM temp_iot2 WHERE location LIKE '%$keyword%'"
		//echo $sql;
		$res = mysqli_query($con,$sql);
		
		if($res)
		{
		
		while($row = mysqli_fetch_assoc($res) )
		{
		    
		    $humidity='humidity';
		    if(strpos($keyword1,$humidity)!== false)
		    {
		    
    ?>
	<div style="word-wrap:break-word;">
		<h4>Humidity :<?php echo $row['humidity']?></h4>

	</div>
	<hr style="border-bottom:1px solid #ccc;"/>
	<?php
		    }
		}
		
		
	   
		}
		
		else 
	   {
	       echo "No Record Found";
	       
	   }
	
	   
	?>
</div>
<?php
	}
	        $iot3='limerick';
	
		if(strpos($keyword1, $iot3) !== false)
	   {
	       
	       
	
		$sql = "SELECT distinct * FROM temp_iot3 where  lower(location) LIKE '%$iot3%'";
		
	//	SELECT distinct * FROM temp_iot3 WHERE location LIKE '$iot3%'"
	//	echo $sql;
		$res = mysqli_query($con,$sql);
		
		if($res)
{
   
		
		while($row = mysqli_fetch_assoc($res) )
		{
		    $Gas='gas';
		    if(strpos($keyword1,$Gas)!==false)
		    {
    ?>
	<div style="word-wrap:break-word;">
		<h4>Gas Power :</h4><?php echo $row['gas']?></h4>
	
	</div>
	<hr style="border-bottom:1px solid #ccc;"/>
	<?php
		    }
		}
	   
	   
	   
	?>
</div>
<?php
	}
	
	else 
	   {
	       echo "No Record Found";
	       
	   }
	
	
	
	   }
	   
	}
?>